//Imports all other files
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import FourButtonScreen from './src/FourButtonScreen';
import MealsScreen from './src/MealsScreen';
import ReviewScreen from './src/ReviewScreen';
import AboutScreen from './src/AboutScreen';
import FavoritesScreen from './src/FavoritesScreen';
import PaprikaChickenRice from './src/Meals/PaprikaChickenRice';
import PaprikaChickenRiceSteps from './src/Steps/PaprikaChickenRiceSteps';
import Login from './src/Login'
import RegisterScreen from './src/RegisterScreen'
import AllRecipes from './src/AllRecipes'

//Create stack for screens
const Stack = createNativeStackNavigator();

//Names all screens
const App = () => (
  <NavigationContainer>
    <Stack.Navigator initialRouteName="WelcomeScreen">
    <Stack.Screen 
  name="WelcomeScreen" 
  component={Login} 
  options={{ headerShown: false }}
/>

      <Stack.Screen name="Home" component={FourButtonScreen} />


      
      <Stack.Screen 
  name="RegisterScreen" 
  component={RegisterScreen} 
  options={{ headerShown: false }} 
/>
<Stack.Screen name="AllRecipes" component={AllRecipes} />
      <Stack.Screen name="Meals" component={MealsScreen} />
      <Stack.Screen name="Review" component={ReviewScreen} />
      <Stack.Screen name="About" component={AboutScreen} />
      <Stack.Screen name="Favorites" component={FavoritesScreen} />
      <Stack.Screen name="PaprikaChickenRice" component={PaprikaChickenRice} />
      <Stack.Screen name="PaprikaChickenRiceSteps" component={PaprikaChickenRiceSteps} />
    </Stack.Navigator>
  </NavigationContainer>
);

export default App;
