const { register } = require('module');
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});


let email;
let password;



async function getEmail() {
    rl.question("Email: ", (inputString) => {
        email = inputString;
        getPassword()
    })
}

async function getPassword() {
    rl.question("Password: ", (inputString) => {
        password = inputString;
        rl.close();
        loginUser();
    })
}

async function loginUser() {
    const loginRequest = {
        "email": email,
        "password": password
    };

    fetch('http://localhost:3000/login', {
        method: 'POST',
        body: JSON.stringify(loginRequest),
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(res => res.json())
        .then(
            (result) => {
                console.log(JSON.stringify(result));
                if (result.message === 'Login successful') {
                    getDetails();
                }
            },
            (error) => {
                console.log(error);
            }
        );
}
// Function to retrieve details from the '/getDetails' endpoint
async function getDetails() {
    fetch('http://localhost:3000/getDetails')
        .then(res => res.json())
        .then(
            (result) => {
                console.log("Retrieved details from server:");
                console.log(JSON.stringify(result));
            },
            (error) => {
                console.log(error);
            }
        );
}

getEmail();