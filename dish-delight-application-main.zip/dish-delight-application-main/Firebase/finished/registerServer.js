const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');

const serviceAccount = require('./dishdelight-b0d5d-firebase-adminsdk-htx5h-a5624dd143.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://dishdelight-b0d5d-default-rtdb.europe-west1.firebasedatabase.app"
});

const app = express();

app.use(cors());
app.use(express.json());

// GET PERSONAL DETAILS
app.post('/register', async (req, res) => {
  if (req.body.email && req.body.password) 
  {
    try 
    {
      const {email, password } = req.body;

      // Check if the user already exists with the provided email
      const userExists = await isUserExists(email);
      if (userExists) 
      {
        res.status(409).json({ message: 'User with this email already exists' });
        console.log("Registration NOT Sent - User already exists");
        return;
      }

      // Add the new user to Firestore
      const userResult = {
        email,
        password,
      };

      const db = admin.firestore();
      await db.collection('user').add(userResult);

      res.status(200).json(userResult);
      console.log("Registration Sent!");
    } 
    
    catch (error) 
    {
      res.status(500).json({ message: error.message });
      console.error("Registration NOT Sent -", error.message);
    }
  }
  
  else 
  {
    res.status(400).send({ message: "Must provide 'firstName', 'lastName', 'email', and 'password' as JSON" });
    console.log("Incorrect input for user");
  }
});

// Function to check if a user already exists with the given email
async function isUserExists(email) 
{
  const db = admin.firestore();
  const userRef = db.collection('user').where('email', '==', email);
  const snapshot = await userRef.get();
  return !snapshot.empty;
}

app.get('/getDetails', async (req, res) => {
  try
  {
    const db = admin.firestore();
    const snapshot = await db.collection('user').get();

    const userDetails = [];
    snapshot.forEach((doc) => {
      userDetails.push(doc.data());
    });

    res.status(200).json(userDetails);
    console.log("PERSONAL DETAILS RETRIEVED FROM FIREBASE");
  } 
  
  catch (error)
  {
    res.status(500).json({ message: error.message });
    console.log("FAILED TO RETRIEVE PERSONAL DETAILS FROM FIREBASE");
  }
});



app.listen(3000, () => {
  console.log("Server started on port 3000");
});



