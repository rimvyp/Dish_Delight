const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');
const serviceAccount = require('./dishdelight-b0d5d-firebase-adminsdk-htx5h-a5624dd143.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://dishdelight-b0d5d-default-rtdb.europe-west1.firebasedatabase.app"
});

const app = express();

app.use(cors());
app.use(express.json());


// Function to check if the provided password matches the stored password
async function isPasswordCorrect(email, password) 
{
  const db = admin.firestore();
  const userRef = db.collection('user').where('email', '==', email).where('password', '==', password);
  const snapshot = await userRef.get();
  return !snapshot.empty;
}

async function isUserExists(email) {
  const db = admin.firestore();
  const userRef = db.collection('user').where('email', '==', email);
  const snapshot = await userRef.get();
  return !snapshot.empty;
}

// POST Login
app.post('/login', async (req, res) => {
  if (req.body.email && req.body.password) {
    try {
      const { email, password } = req.body;

      // Check if the user exists with the provided email
      const userExists = await isUserExists(email);

      if (!userExists) {
        res.status(404).json({ message: 'User with this email does not exist' });
        console.log("Login NOT Successful - User does not exist");
        return;
      }

      // Check if the provided password matches the stored password
      const passwordCorrect = await isPasswordCorrect(email, password);

      if (!passwordCorrect) {
        res.status(401).json({ message: 'Incorrect password' });
        console.log("Login NOT Successful - Incorrect password");
        return;
      }

      res.status(200).json({ message: 'Login successful' });
      console.log("Login Successful!");
    } catch (error) {
      res.status(500).json({ message: error.message });
      console.error("Login NOT Successful -", error.message);
    }
  } else {
    res.status(400).send({ message: "Must provide 'email' and 'password' as JSON" });
    console.log("Incorrect input for login");
  }
});

app.get('/getDetails', async (req, res) => {
  try {
    const db = admin.firestore();
    const snapshot = await db.collection('user').get();

    const userDetails = [];
    snapshot.forEach((doc) => {
      userDetails.push(doc.data());
    });

    res.status(200).json(userDetails);
    console.log("PERSONAL DETAILS RETRIEVED FROM FIREBASE");
  } catch (error) {
    res.status(500).json({ message: error.message });
    console.log("FAILED TO RETRIEVE PERSONAL DETAILS FROM FIREBASE");
  }
});



app.listen(3000, () => {
  console.log("Server started on port 3000");
});


