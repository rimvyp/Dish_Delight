const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');

const serviceAccount = require('./dishdelight-b0d5d-firebase-adminsdk-htx5h-a5624dd143.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://dishdelight-b0d5d-default-rtdb.europe-west1.firebasedatabase.app"
});

const app = express();

app.use(cors());
app.use(express.json());

const db = admin.firestore();
const homeScreenCollection = db.collection('homeScreen');

// GET 5 random entries for homescreen
app.post('/homeScreen', async (req, res) => {
  try {
    const dataArray = req.body;
    console.log('Received Data:', dataArray);

    // Insert data into Firestore
    for (const dataItem of dataArray) {
      await homeScreenCollection.add(dataItem);
    }

    res.status(200).json({ message: 'Data inserted into Firestore successfully' });
    console.log('Data inserted into Firestore!');
  } catch (error) {
    res.status(500).json({ message: error.message });
    console.log('Failed to insert data into Firestore');
  }
});

app.get('/homeScreen', async (req, res) => {
  try {
    let userResult = [];

    // Fetch data from Firestore
    const snapshot = await homeScreenCollection.limit(5).get();

    snapshot.forEach((doc) => {
      userResult.push(doc.data());
    });

    res.status(200).json(userResult);
    console.log('Data retrieved from Firestore!');
  } catch (error) {
    res.status(500).json({ message: error.message });
    console.log('Failed to retrieve data from Firestore');
  }
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});
//This will allow the client to download 5 random meals from the database

