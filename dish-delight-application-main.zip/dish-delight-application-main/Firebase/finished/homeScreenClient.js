// const { register } = require('module');
const readline = require('readline');
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const homeScreen = [
  {
    "title": "",
    "category": [],
    "imageURI": "",
    "mealID": 1
  },
  {
    "title": "",
    "category": [],
    "imageURI": "",
    "mealID": 2
  },
  {
    "title": "",
    "category": [],
    "imageURI": "",
    "mealID": 3
  },
  {
    "title": "",
    "category": [],
    "imageURI": "",
    "mealID": 4
  },
  {
    "title": "",
    "category": [],
    "imageURI": "",
    "mealID": 5
  },
  {
    "title": "",
    "category": [],
    "imageURI": "",
    "mealID": 6
  },
  {
    "title": "",
    "category": [],
    "imageURI": "",
    "mealID": 7
  },
  {
    "title": "",
    "category": [],
    "imageURI": "",
    "mealID": 8
  },
  {
    "title": "",
    "category": [],
    "imageURI": "",
    "mealID": 9
  },
  {
    "title": "",
    "category": [],
    "imageURI": "",
    "mealID": 10
  }
];



async function getTitle(i) {
  rl.question("Title: ", (inputString) => {
    homeScreen[i].title = inputString;
    getCategory(i)
  }) 
}

async function getCategory(i) {
  rl.question("Category: ", (inputString) => {
    homeScreen[i].category = inputString;
    getImageURI(i)
  })
}

async function getImageURI(i) {
  rl.question("ImageURI: ", (inputString) => {
    homeScreen[i].imageURI = inputString;
    getMealID(i)
  })
}

async function getMealID(i) {
  homeScreen[i].mealID = i;
  if (i === homeScreen.length - 1) {
    console.log("Loop Done")
    rl.close();
    postHomeScreen()
  }
  else {
    i++
    console.log("Looping...")
    getTitle(i)
  }
}

async function postHomeScreen() {
  // console.log(JSON.stringify(homeScreen));
  fetch('http://localhost:3000/homeScreen',
    {
      method: 'POST',
      body: JSON.stringify(homeScreen),
      headers:
      {
        'Content-Type': 'application/json'
      }
    })
    .then(res => res.json())
    .then(
      (result) => {
        console.log(JSON.stringify(result));
        console.log(result.length)
        getHomeScreen();
      },
      (error) => {
        console.log(error);
      }
    )
}

async function getHomeScreen() {
  fetch('http://localhost:3000/homeScreen')
    .then((res) => res.json())
    .then(
      (result) => {
        console.log('Retrieved details from server:');
        console.log(JSON.stringify(result));
      },
      (error) => {
        console.log(error);
      }
    );
}

getTitle(0)



//This will allow the client to download 5 random meals from the database
                    