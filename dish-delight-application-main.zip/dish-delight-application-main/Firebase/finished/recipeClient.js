const { register } = require('module');
const readline = require('readline');
const rl = readline.createInterface({
    input:process.stdin,
    output:process.stdout
});

const recipe =
{
    "title": "Chicken & Veg",
    "videoURL": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    "instructionsArray": ["1. Cook chicken","2.Cook veg"],
    "mealID": 1
};

async function postRecipe(i) {
    recipe.mealID = i
    try {
        const response = await fetch('http://localhost:3000/recipe', {
            method: 'POST',
            body: JSON.stringify(recipe),
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const result = await response.json();
        console.log('Response from server:', result);

        // If the server sends an error message, you can log it
        if (result && result.message) {
            console.log('Server error:', result.message);
        } else {
            console.log('Data posted successfully');
            getRecipe();
        }
    } catch (error) {
        console.log('Error posting data to server:', error);
    }
}   
    
async function getRecipe() {
    try {
        const response = await fetch('http://localhost:3000/recipe');
        const result = await response.json();
        console.log('Retrieved details from server:', result);
    } catch (error) {
        console.log('Error retrieving data from server:', error);
    }
}

postRecipe(10)

//This will allow the client to get Meal info by index
                    