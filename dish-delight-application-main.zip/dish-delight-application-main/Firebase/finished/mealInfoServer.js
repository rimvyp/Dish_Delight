const express = require('express')
const cors = require('cors')
const app = express()
const admin = require('firebase-admin');

const serviceAccount = require('C:\\Users\\purce\\OneDrive\\Documents\\College work\\College\\DishDelight2.0\\dishdelight-b0d5d-firebase-adminsdk-htx5h-a5624dd143.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://dishdelight-b0d5d-default-rtdb.europe-west1.firebasedatabase.app"
});

app.use(cors())
app.use(express.json());

const db = admin.firestore();
const homeScreenCollection = db.collection('mealInfo');


app.post('/mealInfo', async (req, res) => {
  try {
    const data = req.body;

    // Log received data for debugging
    console.log("Received Data:", data);

    // Insert data into Firestore
    const docRef = await homeScreenCollection.add(data);
    console.log("Document added with ID:", docRef.id);

    res.status(200).json(data);
    console.log("meal info Sent!");
  } catch (error) {
    res.status(500).json({ message: error.message });
    console.log("meal info NOT Sent");
  }
});



app.get('/mealInfo', async (req, res) => {
  try {
    let userResult = [];

    // Fetch data from Firestore
    const snapshot = await homeScreenCollection.get();

    snapshot.forEach((doc) => {
      userResult.push(doc.data());
    });

    res.status(200).json(userResult);
    console.log('Data retrieved from Firestore!');
  } catch (error) {
    res.status(500).json({ message: error.message });
    console.log('Failed to retrieve data from Firestore');
  }
});

app.listen(3000, () => { console.log("Server started on port 3000") })
