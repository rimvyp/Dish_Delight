const { register } = require('module');
const readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const mealInfo = {
    "title": "Chicken and Veg",
    "mealType": ["high protein", "carbs"],
    "timeToCook": "20 minutes",
    "ingredients": ["Chicken", "Veg"],
    "equipment": ["pan", "Hob", "Knife", "spatula"],
    "calories": 100,
    "allergies": ["Chicken", "veg"],
    "macros": { "carbs": "100g", "protein": "18g", "fat": "10g" },
    "mealID": 0
};

async function postMealInfo(i) {
    mealInfo.mealID = i;
    try {
        const response = await fetch('http://localhost:3000/mealInfo', {
            method: 'POST',
            body: JSON.stringify(mealInfo),
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const result = await response.json();
        console.log('Response from server:', result);

        // If the server sends an error message, you can log it
        if (result && result.message) {
            console.log('Server error:', result.message);
        } else {
            console.log('Data posted successfully');
            getMealInfo();
        }
    } catch (error) {
        console.log('Error posting data to server:', error);
    }
}

async function getMealInfo() {
    try {
        const response = await fetch('http://localhost:3000/mealInfo');
        const result = await response.json();
        console.log('Retrieved details from server:', result);
    } catch (error) {
        console.log('Error retrieving data from server:', error);
    }
}

// Example usage:
postMealInfo(10);



