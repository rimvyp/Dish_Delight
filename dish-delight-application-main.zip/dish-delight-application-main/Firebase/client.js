// const ip = "192.168.0.172" // home server
// const ip = "149.157.101.204" // laptop
// const ip = "35.214.78.162" //VM
const ip = "localhost" //for webview

//POST registration
async function registerUser(email,password) {
    const getRequest =
    {
        "email": email,
        "password": password
    }

    try
    {
        const response = await fetch('http://'+ip+':3000/register',
        {
            method: 'POST',
            body: JSON.stringify(getRequest),
            headers:
            {
                'Content-Type': 'application/json'
            }
        })
        
        const result = await response.json();
        return result;
    }
    
    catch (error) 
    {
        console.log(error);
        throw error;
    }
}

//POST Login
async function loginUser(email, password) {
    const loginRequest = {
        "email": email,
        "password": password
    };

    try
    {
        const response = await fetch(`http://${ip}:3000/login`,{
            method: 'POST',
            body: JSON.stringify(loginRequest),
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        // console.log(result);
        return result;
    }

    catch (error) 
    {
        console.log(error);
        throw error;
    }
}


//Gets 3 arrays of JSON objects from Firebase.
    async function getHomeScreen(userId)
    {
        try
        {
            const response = await fetch(`http://${ip}:3000/homeScreen/${userId}`)
            const result = await response.json();
            // console.log(result)
            return result;
        }

        catch (error) 
        {
            console.log(error);
            throw error;
        }
    }


      //returns all meals from the meals collection
      async function getAllMeals()
      {
          try 
          {
            const response = await fetch(`http://${ip}:3000/allMeals`)
            const result = await response.json();
            // console.log(result);
            return result;
          }

          catch (error) 
          {
            console.log(error);
          }
      }

      //gets the info from the homescreen collection based on a meal ID. Used to display the all favourites screen
      async function getClickableInfo(mealInfo) 
      {
          try 
          {
            const response = await fetch(`http://${ip}:3000/clickableInfo/${mealInfo}`)
            const result = await response.json();
            // console.log(result);
            return result;
          }

          catch (error) 
          {
            console.log(error);
          }
      }

      //gets the meal info based on the mealID, more detailed than homescreen 
      async function getMealInfo(mealInfo) 
      {
          try 
          {
            const response = await fetch(`http://${ip}:3000/mealInfo/${mealInfo}`)
            const result = await response.json();
            // console.log(result);
            return result;
          }

          catch (error) 
          {
            console.log(error);
          }
      }

      //gets the recipe based on the mealID, more detailed than meal info
    async function getRecipe(mealInfo)
    {
        try 
        {
            const response = await fetch(`http://${ip}:3000/recipe/${mealInfo}`)
            const result = await response.json();
            // console.log(result);
            return result;
        }

        catch (error) 
        {
            console.log(error);
        }
    }

    //post favourite based on a user ID and mealID. (Was designed to post multiple favourites, potential to store array locally for offline mode?)
    async function postFavourites(userId, data)
    {
        try 
        {
            userId = "User" + userId
            const response = await fetch(`http://${ip}:3000/favourites/${userId}`, {
            method: 'POST',
            //puts numbers into array after splitting by commas
            body: JSON.stringify(data.split(',').map(Number)),
            headers:
            {
                'Content-Type': 'application/json'
            }
        });
            const result = await response.json();
            // console.log(result);
        }

        catch (error)
        {
            console.log(error);
        }
    }
    
    // is favourite checks if a a userID has a mealID in their favourites already (Predicate)
    async function isFavourite(userId,mealId)
    {
        try 
        {
            userId = "User" + userId
            const response = await fetch(`http://${ip}:3000/isFavourite/${userId}/${mealId}`);
            const data = await response.json();
            // console.log("Answer is :" + data.message);
            return data.message
        }

        catch (error) 
        {
            console.log(error);
        }
    }
        
        
    //gets all favourites
    async function getFavourites(userId)
    {
        try 
        {
            userId = "User"+userId
            const response = await fetch(`http://${ip}:3000/favourites/${userId}`);
            const data = await response.json();
            // console.log(data);
            return data
        } 

        catch (error) 
        {
            console.log(error);
        }
    }

// Export an object containing all the functions
module.exports = 
{
  registerUser,
  loginUser,
  getAllMeals,
  getHomeScreen,
  getClickableInfo,
  getMealInfo,
  getRecipe,
  postFavourites,
  isFavourite,
  getFavourites
};