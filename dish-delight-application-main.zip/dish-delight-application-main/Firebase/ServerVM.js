//require express for routes
const express = require('express');
//requires cors to ensure express works
const cors = require('cors');
//requires firebase admin to interact with the database
const admin = require('firebase-admin');

//JSON to connect to firebase
const serviceAccount = {
    "type": "service_account",
    "project_id": "dishdelight-b0d5d",
    "private_key_id": "a5624dd1436f90c6361e3e24b2d26caaaa77e89a",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC2XnmL7qRtY4VM\n5y+0yGWYH40U/kAwsF/JH67daGUA+5AA2hzFj3PbtgnsMERbbjwIlMzEEjSv/+5v\nnlJ2MzZ1Gtv6I9htucFlL7y3VpVQk6Y2oJq716W3MqYWdW1R5A+R7+VpWvNR79WX\nwjqwM0t5fSwgIH7C58dWow/nqbTSC8gKd0btC7lK/WFJDgaAKzsZgblKYYxzVlrh\n8jfUwlqxTKwFw0qLnq+t43aoddml+QtZePDwzwkcZYZil4oV8NczzrR5dD7QRZmp\ncIhXgsfkv7LbFW7xTeYPdBFP4hfU2S5gjNlZhTLwkJPfSqS94WKW/ibRWRaA0333\nKc34sDtfAgMBAAECggEAT9KjVf3zB5RHfOU2KuWKHl81A+rTktwoWOKeyfePOjJi\nEhVmAY0sM4+G4VQxH2ntKf5jcDDd0eluZnnAc08wN2q1vVOiQEjNnyoZapAh0/6E\ngqWihLS7qqenLe5hFraBoCmGWyp9lTAqZ/4SbRxOnVMOFNPUWCBWTpQZ+pb79/GF\n3nh/zVnvF4WOZZvF9ThX8rxlUajFb6hp9MBG4EYPfSy7ee98MWE0G5I57yhtU5B6\n6bMG3s0wY+lnzji3MZqhbIzLOjqLmSP6vaPbAYlL2/jOYvz7Nrm5xSJ1qGgrpt9M\nhODoH6tB613lN6MN0aSAlFzBFpv95GmBxiq72uL0gQKBgQDhl/3vOjrYHepcM0nj\nd5UJ/Khm4HJzLku43tPW97guCa6r6fLgio4tBqgVGcU6ivQuUN4RkN6wScsUuzcU\nNEoWK2egItQ2aHqCGN9P4a4m/IcsGDuc2uvROOVUIKL2/B9C8MvG9JUT9c6R3YRH\npXeHmOzAWWx8WLtPpfAML6W93wKBgQDO8wkBL977COp33422A3T6ch0di5v57Y2F\nZ1Ux9yYHjdZQ+a7m5JsI15KBVESNT3ggVcv93cx4Iyt8PvPbKm09nYt2LRD9eK+8\nRrnmpsu/7idu2+qHnJoKrKxnzCEum4qM0sC8txeiA9J7QfFwAR0SmNFpuPyTp/Rt\noTJin6oygQKBgAKpLUiWEj2cVLhTroptTae5gC7+dLshD6mVj0AY2eZJHPNQJho5\n6CVlz7O4AxiGrQyizYu9frLrm+aZsrOdTkZmqqk73+7oWpGQQ4oIqmoxTlLZ0lIu\nTtu/5QyR+foZzTCX8H9fQSbkHlSgHUBPFlLWHezC4UGyNjthRKyQH09XAoGAak1s\n0q9EWq65wdmTcWtVK1BypDqSZE8h4uSxXnkVj8vLysx2iyPifyg8mTIwBGZNzk5D\n+qNz5EIslCXCHVItyviiKpH7qDfWDWBHHbOP9YbfupI8ZmyKs/D+nlK8uLQs9ylK\n16U0/oP4GlhFLMNlq6fT6fqbwz0C0U18FCzvwAECgYBtgDQvMdev/SpdXxtcn+6b\nz6Hr1doXNYEsdJEcqctPBYd3Eo3P2eLwYnz5RnfFLysGZQkD174iHpmcZsCAiS/U\noe3JxxtlDBLUDxmcqW4U4tF0pc/MH3tEuspnFOpGO9KY93kjVtIBoLh8PqjFfFeq\n1Xr2oYC+kjDs83yVa5nZ4Q==\n-----END PRIVATE KEY-----\n",
    "client_email": "firebase-adminsdk-htx5h@dishdelight-b0d5d.iam.gserviceaccount.com",
    "client_id": "106722335519951883294",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-htx5h%40dishdelight-b0d5d.iam.gserviceaccount.com",
    "universe_domain": "googleapis.com"
}

//initialise connection
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://dishdelight-b0d5d-default-rtdb.europe-west1.firebasedatabase.app"
  });
  
  //sets up an express.js application
  const app = express();
  
  //configures cors
  app.use(cors());
  
  //middleware will be set up to handle JSON
  app.use(express.json());
  
  //creates reference to firestore
  const db = admin.firestore();
  
  //creates reference to recipes collection
  const recipeCollection = db.collection('recipe');

  //creates reference to mealInfo collection
  const mealInfoCollection = db.collection('mealInfo');
  
  //creates reference to homeScreen collection
  const homeScreenCollection = db.collection('homeScreen');

  //creates reference to favourites collection
  const favouritesCollection = db.collection('favourites');

  //Post registration route
  app.post('/register', async (req, res) => {

    try {
        //Parses JSON
        const { email, password } = req.body;

        // Check if the user already exists with the provided email
        const userExists = await isUserExists(email);

        if (userExists) 
        {
            res.status(409).json({ message: 'User with this email already exists' });
        }
        else 
        {
          //defines counters collection and gets the UserID document
          const counterRef = db.collection('counters').doc('UserIdCounter');
          //counterDoc is whatever is in the UserID docuemnt
          let counterDoc = await counterRef.get();

          // If the counter document does not exist, create it with a default value for the currentID
          if (!counterDoc.exists) 
          {
              await counterRef.set({ currentUserId: 0 });
              counterDoc = await counterRef.get();
          }

          //currectUserID is the gotten from the document 
          let currentUserId = counterDoc.data().currentUserId;
          // Increment the UserID for the new user
          currentUserId++;
          // Update the counter document with the new UserID
          await counterRef.update({ currentUserId });

            // Add the new user to Firestore
            const userResult = {
              email,
              password,
              UserId: currentUserId,
              createdAt: admin.firestore.FieldValue.serverTimestamp()
          };

          //Sets up userID
          await db.collection('user').doc(`User${currentUserId}`).set(userResult);
          //Sets up empty favourites array for user
          await db.collection('favourites').doc(`User${currentUserId}`).set({ favourites: [] });
          // The ID of the new user is 'UserId' followed by the current UserID

            //returns all users
            res.status(200).json({message:"success"});
        }
    }
    catch (error) 
    {
        //responds with error message
        res.status(500).json({ message: error.message });
    }
});

//Post login route
app.post('/login', async (req, res) => {
    try 
    {
        //Parses JSON
        const { email, password } = req.body;
        // Check if the user exists with the provided email
        const userExists = await isUserExists(email);
        
        if (!userExists)
        {
          res.status(404).json({ message: 'User with this email does not exist' });
        }

        else
        {
            // Check if the provided password matches the stored password
            const passwordCorrect = await isPasswordCorrect(email, password);
            
            if (!passwordCorrect) 
            {
              res.status(401).json({ message: 'Incorrect password' });
            }
            
            else
            {
              const response = {
                "message": "Login successful",
                "id":passwordCorrect
              }
              res.status(200).json(response); 
            }
        }
    }
    
    catch (error) 
    {
        res.status(500).json({ message: error.message });
    }
});


app.get('/homeScreen/:userId', async (req, res) => {
  try 
  {
    
    // Fetch data from homeScreen collection
    const homeScreenSnapshot = await homeScreenCollection.get();

    //makes array of all meals in Firebase
    let meals = []
    homeScreenSnapshot.forEach((doc) => {
      meals.push(doc.data());
    });
    
    // 3 latest meals
    let latestMeals = [];
    for(let i = 0; i < 3; i++) 
    {
      latestMeals.push(meals[i]);
    }

    const suggested = getRandomEntries(meals,3)//return 3 random suggestions
    
    
    //gets the userID
    const userId = req.params.userId;

    const favouritesSnapshot = await db.collection('favourites').doc("User"+userId).get();
    const favouritesObject = favouritesSnapshot.data()

    let favourites = []
    for (let i = 0; i < favouritesObject.favourites.length;i++) 
    {
      meals.forEach((meal) => {
          if(meal.MealId===favouritesObject.favourites[i])
          {
            favourites.push(meal);
          }
        });
    }
    
    const randomFavourites = getRandomEntries(favourites,3)//return 3 random suggestions
    
    //JSON will return 3 arrays
      const response = {
        "latestMeals": latestMeals,
        "suggested":suggested,
        "favourites": randomFavourites
      }
      res.status(200).json(response);
    } 
    
    catch (error) 
    {
      res.status(500).json({ message: error.message });
    }
  });


  function getRandomEntries(snapshot,meals)
  {
    try
    {  
      const dataArray = snapshot;
      
      const loop = meals;
      let userResult = []
      for(let i=0;i<loop;i++)
      {
        userResult[i] = 0;
      }

      let selected =[]
      for(let i=0;i<dataArray.length;i++)
      {
        selected[i] = false;
      }

      function assignMenu(i,loop)
      {
              const randomFavourite = Math.floor(Math.random() * dataArray.length)

              if(selected[randomFavourite]===false)
              {

                userResult[i] = dataArray[randomFavourite];
                selected[randomFavourite] = true
                if(i<loop-1)
                {
                  i++
                  assignMenu(i,loop)
                }
              }
              else
              {
                assignMenu(i,loop)
              }
      }
      assignMenu(0,loop) //assigns loops amount of meals
      return userResult;
      }

    catch(error)
    {
      console.log("Random Entries NOT Sent");
      return {};
    }
}

  //Get meal info route
  app.get('/mealInfo/:mealId', async (req, res) => {
    try 
    {
      const targetID = req.params.mealId;
      let userResult = [];
      let answer = {};
      
      // Fetch data from the mealInfo collection
      const snapshot = await mealInfoCollection.get();
      
      snapshot.forEach((doc) => {
        userResult.push(doc.data());
      });

        userResult.forEach((meal) => {
            if(meal.MealId==targetID)
            {
              answer = meal;
            }
          });

          
      res.status(200).json(answer);
    } 
    
    catch (error) 
    {
      res.status(500).json({ message: error.message });
    }
  });
  
  //Get recipe route
  app.get('/recipe/:mealId', async (req, res) => {
    try 
    {
      const targetID = req.params.mealId;

      //array to store JSON objects
      let userResult = [];
      let answer = {};
      
      // Fetch data from Firestore
      const snapshot = await recipeCollection.get();
      
      //for each to save data to array
      snapshot.forEach((doc) => {
        userResult.push(doc.data());
      });

      userResult.forEach((meal) => {
        if(meal.MealId==targetID)
        {
          answer = meal;
        }
      });
      
      res.status(200).json(answer);
    } 
    
    catch (error) 
    {
      res.status(500).json({ message: error.message });
    }
  });


// POST favourites
app.post('/favourites/:userId', async (req, res) => {
  try 
  {
    //gets userId
      const userId = req.params.userId;
      //gets array
      const dataArray = req.body;

      //gets reference to the user
      const userRef = db.collection('favourites').doc(userId);

      // Check if dataArray is an array of numbers
      if (!Array.isArray(dataArray) || !dataArray.every(Number.isInteger)) {
          res.status(400).json({ message: 'Data should be an array of numbers' });
          return;
      }

      // Get the current favourites data
      let doc = await userRef.get();
      //if document exists, if it's an array, retrieve the array, else, give empty array
      let currentFavourites = Array.isArray(doc.data().favourites) ? doc.data().favourites : [];

      // Merge the new data with the current data
      let newFavourites = [...new Set([...currentFavourites, ...dataArray])];

      // Update the favourites field in the user document with the new data
      await userRef.update({ favourites: newFavourites });

      res.status(200).json({ message: 'Favourites Updated!' });
  } catch (error) {
      res.status(500).json({ message: error.message });
  }
});


// GET favourites
app.get('/favourites/:userId', async (req, res) => {
  try 
  {
    //gets the userID
      const userId = req.params.userId;

      //gets a snapshot of the document
      // const snapshot = await favouritesCollection.doc(userId).get();
      const snapshot = await favouritesCollection.doc(userId).get();


      if (!snapshot.exists) 
      {
          res.status(404).json({ message: 'User not found' });
      }

      else
      {
        //save snapshot data
        const userResults = snapshot.data();


        res.status(200).json(userResults);
      }
  } 
  
  catch (error) 
  {
      res.status(500).json({ message: error.message });
  }
});

  app.listen(3000, () => {
    console.log("Server\nstarted\non\nport\n3000");
  });
  // Function to check if a user already exists with the given email  
  async function isUserExists(email) 
  {
      //designs the query for firebase
      const userRef = db.collection('user').where('email', '==', email);
      // Checks firebase to see if the email already exists in the user collection
      const snapshot = await userRef.get();
      //returns if the user exists
      return !snapshot.empty;
    }
    
    // Function to check if the provided password matches the stored password
    async function isPasswordCorrect(email, password) 
    {
      const userRef = db.collection('user').where('email', '==', email).where('password', '==', password);
      const snapshot = await userRef.get();
      try{

        const documentId = snapshot.docs[0].id;
        return documentId;
      }
      catch{

        console.log("fu- I mean oops");
        return false
      }
    }