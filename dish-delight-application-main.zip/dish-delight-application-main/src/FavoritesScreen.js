import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, FlatList, TouchableOpacity, Image, Modal } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
const api = require('../Firebase/client.js');
import { clicked } from './FourButtonScreen';
import { getId } from './Login';

const FavoritesScreen = ({ navigation }) => {
  const [isMenuVisible, setMenuVisible] = useState(false);
  const [allDishes, setAllDishes] = useState([]);

  useEffect(() => {
    const fetchAllMeals = async () => {
      try
      {
        //gets favourites of a user
        const favoriteDishes = await api.getFavourites(getId());
  
        // Create an array of promises by mapping through favoriteDishes.favourites
        const mealInfoPromises = favoriteDishes.favourites.map(async (favorite) => {
          const mealInfo = await api.getClickableInfo(favorite);
          return mealInfo;
        });
  
        // Wait for all promises to resolve using Promise.all
        const allMealInfo = await Promise.all(mealInfoPromises);
  
        // Now allMealInfo is an array containing the results of getMealInfo for each favorite dish
        console.log(allMealInfo);
  
        setAllDishes(allMealInfo);
      } catch (error) {
        console.error('Error fetching all meals:', error);
      }
    };
  
    fetchAllMeals();
  }, []);

  React.useEffect(() => {
    navigation.setOptions({
      headerTitle: () => (
        <View style={styles.headerTitle}>
          <Icon name="star" size={24} color="gold" />
          <Text style={styles.titleText}> Favorites</Text>
        </View>
      ),
      headerStyle: {
        backgroundColor: '#008000', // Green background for the header
      },
      headerTintColor: '#fff', // White color for header text and icons
    });
  }, [navigation]);


  const toggleMenu = () => {
    setMenuVisible(!isMenuVisible);
  };

  const handleMealClick = (mealID,photo) => {
    console.log(mealID);
    clicked(mealID,photo);
    navigation.navigate('PaprikaChickenRice');
  };

  return (
    <View style={styles.container}>
   
      <TextInput
        style={styles.searchInput}
        placeholder="Search your favorites..."
      />
    

    <FlatList
  data={allDishes}
  keyExtractor={(item) => item.MealId && item.MealId.toString()}
  renderItem={({ item }) => (
    <TouchableOpacity onPress={() => handleMealClick(item.MealId, item.ImageURL)}>
      <View style={styles.dishItem}>
        <Image source={{ uri: item.ImageURL }} style={styles.dishImage} />
        <Text style={styles.dishName}>{item.Title}</Text>
      </View>
    </TouchableOpacity>
  )}
  ItemSeparatorComponent={() => <View style={styles.separator} />}
/>

    


    </View>
  );
};

const styles = StyleSheet.create({
  headerTitle: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  titleText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    marginLeft: 10,
  },
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center', // Center the content horizontally
    backgroundColor: '#008000', // Set to the same green color as the previous page
    padding: 8,
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  dishItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 10,
    marginVertical: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  dishImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginRight: 10,
  },
  dishName: {
    fontSize: 18,
    color: 'black',
  },
  separator: {
    height: 1,
    backgroundColor: 'lightgray',
  },
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center', // Center the content horizontally
    backgroundColor: 'green', // Set the background color to green
    padding: 8,
    marginBottom: 16,
    
  },
  backgroundContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  menuIcon: {
    padding: 8,
  },
  menuPlaceholder: {
    width: 24,
  },
  searchInput: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 8,
    padding: 8,
    marginBottom: 16,
    backgroundColor: 'white',
  },
  dishItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    marginBottom: 20,
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
  },
  dishImage: {
    width: 100,
    height: 100,
    marginRight: 8,
    borderRadius: 8,
  },
  dishName: {
    fontSize: 18,
    marginLeft: 8,
    color: 'black',
  },
  separator: {
    height: 2,
    backgroundColor: 'lightgray',
  },
  showAllContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  showAllText: {
    fontSize: 18,
    color: 'blue',
  },
  menuContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  closeButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    padding: 8,
  },
  closeButtonText: {
    color: 'white',
    fontSize: 16,
  },
  menuOption: {
    fontSize: 24,
    color: 'white',
    marginBottom: 20,
  },
});

export default FavoritesScreen;