import React, { useRef, useState } from 'react';
import { ScrollView, View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import * as Animatable from 'react-native-animatable';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { getImage, getMealID } from '../FourButtonScreen';
import { getId } from '../Login';
const api = require('../../Firebase/client.js');


const PaprikaChickenRice = () => {
    const navigation = useNavigation();
    const navRef = useRef();
    const [isNavbarVisible, setIsNavbarVisible] = useState(false);
    const [isFavorite, setIsFavorite] = useState(false);
    const [imageofMeal, setImage] = useState('https://i.postimg.cc/mZMm8ncV/Screenshot-from-2023-12-11-18-30-50.png');
    
    
    //backend
    const ID = getId(); // gets ID of user
  const MealID = getMealID(); //gets ID from meal clicked

React.useEffect(() => {
    const image = getImage();
    setImage(image);
    console.log("ID = " + ID);
    console.log("MealID = " + MealID);
  
    const fetchData = async () => {
      try {
        //Checks if meal is a favourite
        const isFavorite = await api.isFavourite(ID, MealID);
        console.log("Is favorite:", isFavorite);
        setIsFavorite(isFavorite);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
  
    fetchData();
  }, [ID, MealID]);
  

const toggleNavbar = () => {
    if (isNavbarVisible) {
        hideNavbar();
    } else {
        showNavbar();
    }
};

const showNavbar = () => {
    setIsNavbarVisible(true);
    navRef.current.slideInDown();
    };

    const hideNavbar = () => {
      if (navRef.current) {
          navRef.current.slideOutUp().then(() => {
              setIsNavbarVisible(false);
          });
      }
  };

    const navigateTo = (page) => {
        console.log(`${page} pressed`);
        navigation.navigate(page);
        hideNavbar();
    };

    const handleFavoritePress = () => {
        console.log("Add to Favorites");
        setIsFavorite(!isFavorite); // insert here
        api.postFavourites(ID,MealID+"")
    };

        // Define MealInfo data
        const [tempTitle, setTitle] = useState("Loading...")
        const [tempCategory, setCategory] = useState("Loading...")
        const [tempCalories, setCalories] = useState("Loading...");
        const [tempMacros, setMacros] = useState(["Loading..."]);
        const [tempTimeToCook, setTimeToCook] = useState("Loading...");
        const [tempAllergy, setAllergy] = useState(["Loading..."]);
        const [tempIngredients, setIngredients] = useState(["Loading..."]);
        const [tempEquipment, setEquipment] = useState(["Loading..."]);
    
        const mealInfo = {
          title: tempTitle,
          category: tempCategory,
          calories: tempCalories,
          macros: tempMacros,
          timeToCook: tempTimeToCook,
          allergy: tempAllergy,
          Equipment: tempEquipment,
          Ingredients: tempIngredients
        };


        const loadInfo = async () => {


            const result = await api.getMealInfo(MealID);
      
            console.log(result);
            setTitle(result.Title);
            setCategory(result.Title);
            setAllergy(result.Allergies);
            setCalories(result.Calories);
            setMacros(result.Macros.join(', '));
            setTimeToCook(result.TimeToCook);
            setIngredients(result.Ingredients);
            setEquipment(result.Equipment);
          }
          loadInfo();

    React.useLayoutEffect(() => {
        navigation.setOptions({
            title: mealInfo.title,
            headerStyle: {
                backgroundColor: '#008000',
            },
            headerTintColor: 'white',
            headerRight: () => (
                <TouchableOpacity style={styles.navBtn} onPress={toggleNavbar}>
                </TouchableOpacity>
            ),
        });
    }, [navigation, toggleNavbar, mealInfo]);

    return (
        <View style={styles.outerContainer}>
            <ScrollView style={styles.scrollView}>
                <View style={styles.container}>
                    {/* Title and Favorite Icon */}
                    <View style={styles.titleContainer}>
                        <Text style={styles.title}>{mealInfo.title}</Text>
                        <Animatable.View 
                            animation={isFavorite ? 'bounce' : undefined} 
                            duration={500}
                            useNativeDriver={true}
                        >
                            <TouchableOpacity onPress={handleFavoritePress} style={styles.favoriteIcon}>
                                <Icon 
                                    name="star" 
                                    size={isFavorite ? 35 : 30} 
                                    color={isFavorite ? "#FFD700" : "#A0A0A0"} 
                                    style={isFavorite ? {} : styles.unfavoritedStar} 
                                />
                            </TouchableOpacity>
                        </Animatable.View>
                    </View>

                    {/* Recipe Image */}
                    <View style={styles.imageContainer}>
                    <Image
            source={{ uri: imageofMeal }}

            
            style={styles.image}
            onError={(error) => console.error('Image loading error:', error.nativeEvent.error)}
          />
                    </View>

                    {/* Link to Instructions */}
                    <TouchableOpacity
                        style={styles.linkButton}
                        onPress={() => navigation.navigate('PaprikaChickenRiceSteps')}
                    >
                        <Text style={styles.linkText}>Instructions</Text>
                    </TouchableOpacity>

                    {/* Meal Information */}
                    <Text style={styles.category}>{mealInfo.category}</Text>
                    <Text style={styles.nutrition}>Calories: {mealInfo.calories}</Text>
                    <Text style={styles.nutrition}>Macros: {mealInfo.macros}</Text>
                    <Text style={styles.heading}>Duration</Text>
                    <Text style={styles.detail}>{mealInfo.timeToCook} minutes</Text>
                    <Text style={styles.heading}>Allergy Information:</Text>
                    <Text style={styles.detail}>{mealInfo.allergy}</Text>
                    <Text style={styles.heading}>Ingredients</Text>
                    {mealInfo.Ingredients.map((ingredient, index) => (
                        <Text key={index} style={styles.detail}>- {ingredient}</Text>
                    ))}
                    <Text style={styles.heading}>Equipment</Text>
                    {mealInfo.Equipment.map((equipment, index) => ( //here
                        <Text key={index} style={styles.detail}>- {equipment}</Text>
                    ))}
                    
                </View>
            </ScrollView>

         
        </View>
    );
};

const styles = StyleSheet.create({
    outerContainer: {
        flex: 1,
        backgroundColor: '#fff',
    },
    scrollView: {
        flex: 1,
    },
    container: {
        padding: 20,
    },
    titleContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        width: '100%',
        paddingRight: 20,
    },
    title: {
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    imageContainer: {
        marginBottom: 20,
    },
    image: {
        width: '80%',
        height: 200,
        resizeMode: 'cover',
        borderRadius: 8,
    },
    linkButton: {
        padding: 10,
        backgroundColor: '#008000',
        borderRadius: 8,
        marginTop: 10,
        marginBottom: 20, // Add a margin at the bottom
    },
    linkText: {
        color: 'white',
        fontSize: 16,
        textAlign: 'center',
    },
    category: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 10,
    },
    nutrition: {
        fontSize: 16,
        marginBottom: 5,
    },
    heading: {
        fontSize: 20,
        fontWeight: 'bold',
        marginTop: 15,
        marginBottom: 8,
    },
    detail: {
        fontSize: 16,
        marginBottom: 3,
        paddingLeft: 10,
    },
    hotbar: {
        flexDirection: 'row',
        justifyContent: 'space-evenly',
        backgroundColor: '#ddd',
        padding: 10,
    },
    button: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 10,
        marginHorizontal: 5,
        backgroundColor: '#008000',
        borderRadius: 5,
    },
    buttonText: {
        fontSize: 16,
        color: 'white',
    },
    favoriteIcon: {
        // Additional styling if needed
    },
    unfavoritedStar: {
        textShadowColor: 'rgba(0, 0, 0, 0.75)',
        textShadowOffset: { width: 1, height: 1 },
        textShadowRadius: 1,
    },
    navBtn: {
        // Additional styling if needed
    },
});

export default PaprikaChickenRice;
