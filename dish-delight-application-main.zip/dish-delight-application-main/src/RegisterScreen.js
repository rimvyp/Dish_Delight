import React, { useState } from 'react';
import {
  ScrollView, Alert, KeyboardAvoidingView, Platform, View, Image, Text, TextInput, Button, StyleSheet
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
const api = require('../Firebase/client.js');

const RegisterScreen = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigation = useNavigation();
 
  const handleRegister = async () => {
    const emailRegex = /\S+@\S+\.\S+/;
    if (emailRegex.test(email)) 
    {
        try 
        {
          //attempts to register user
            const register = await api.registerUser(String(email), String(password));

            if (register.message === "success") 
            {
                Alert.alert('Registration Successful', 'You have been registered successfully.', [
                    { text: "OK", onPress: () => navigation.navigate('WelcomeScreen') }
                ]);
                console.log('Registration Successful', 'You have been registered successfully.');
                navigation.navigate('WelcomeScreen')
            }
            else 
            {
                Alert.alert(
                    "Registration Failed",
                    "User with this email already exists",
                    [{ text: "OK", onPress: () => console.log("OK Pressed") }]
                );
                console.log("User with this email already exists");
            }
        }

        catch (error) 
        {
            console.error(error);
        }
    }

    else 
    {
        Alert.alert('Invalid Email', 'Please enter a valid email address.');
        console.log('Invalid Email', 'Please enter a valid email address.');
    }
};


  const navigateBackToLogin = () => {
    navigation.navigate('WelcomeScreen'); 
  };


  return (
    <KeyboardAvoidingView
      style={styles.keyboardAvoidingView}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS === "ios" ? 64 : 0}
    >
      <ScrollView style={styles.scrollView}>
        <View style={styles.container}>
          <Image
            source={{ uri: 'https://i.postimg.cc/4yrNXrys/Recipe-Haven.png' }}
            style={styles.image}
          />
          <Text style={styles.text}>Register for Healthy Recipes!</Text>
          <View style={styles.form}>
            <TextInput
              style={styles.input}
              placeholder="Email"
              onChangeText={setEmail}
              value={email}
              keyboardType="email-address"
            />
            <TextInput
              style={styles.input}
              placeholder="Password"
              secureTextEntry
              onChangeText={setPassword}
              value={password}
            />
            <Button
              title="Register"
              onPress={handleRegister}
              color="rgb(68, 214, 44)"
            />
             <Button
            title="Already have an account? Log In"
            onPress={navigateBackToLogin}
            color="rgb(68, 214, 44)"
          />
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  keyboardAvoidingView: {
    flex: 1,
    backgroundColor: 'white', // Ensure the entire background is white
  },
  scrollView: {
    flex: 1,
    backgroundColor: 'white', // Ensure the entire background is white
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  text: {
    textAlign: 'center',
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  form: {
    width: '80%',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
  },
  image: {
    width: '60%',
    height: 250,
    marginBottom: 30,
  },
  button: {
    marginBottom: 20,
  },
});

export default RegisterScreen;
