//calls the client api
const api = require('../Firebase/client.js');

//methods to test the client API

// api.registerUser("curtis@king.ie","321") 
// api.loginUser("curtis@king.ie","321") 
// api.getHomeScreen(1) 
// api.getMealInfo(11) 
// api.getRecipe(4) // 
// api.isFavourite(2,1) 
// api.postFavourites(1,"4,5,6")
// api.getFavourites(10)