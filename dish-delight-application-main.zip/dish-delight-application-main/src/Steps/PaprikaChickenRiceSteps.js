import React, { useRef, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions, ScrollView } from 'react-native';
import * as Animatable from 'react-native-animatable';
import { useNavigation } from '@react-navigation/native';
import { WebView } from 'react-native-webview';
import { getMealID } from '../FourButtonScreen';
const api = require('../../Firebase/client.js');

const PaprikaChickenRiceSteps = () => {
  const screenWidth = Dimensions.get('window').width;
  const navRef = useRef();
  const [isNavbarVisible, setIsNavbarVisible] = useState(false);
  const navigation = useNavigation();
  const MealID = getMealID(); //gets ID from meal clicked

  // Define MealInfo data
  const [tempTitle, setTitle] = useState("Loading...")
  const [tempVideoURL, setVideoURL] = useState("https://www.youtube.com/watch?v=hDekr_h9OSE")
  const [tempInstructions, setInstructions] = useState(["Loading..."]);

  const loadInfo = async () => {
      
      
    const result = await api.getRecipe(MealID)
    
    setTitle(result.Title);
      setVideoURL(result.VideoURL);
      setInstructions(result.Instruction);
  }

  React.useEffect(() => {
    loadInfo();
  });

  const Recipe = {
    title: tempTitle,
    videoURL: tempVideoURL, // Use the embed URL for the video
    InstructionsArray: tempInstructions
  };

  const toggleNavbar = () => {
    if (isNavbarVisible) {
      hideNavbar();
    } else {
      showNavbar();
    }
  };

  const showNavbar = () => {
    setIsNavbarVisible(true);
    navRef.current.slideInDown();
  };

  const hideNavbar = () => {
    navRef.current.slideOutUp().then(() => {
      setIsNavbarVisible(false);
    });
  };

  const Section = ({ title, onPress }) => (
    <TouchableOpacity onPress={onPress}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{title}</Text>
        <View style={styles.imageRow}>
          <Text style={styles.imagePlaceholder}>Replace with Image</Text>
          <Text style={styles.imagePlaceholder}>Replace with Image</Text>
          <Text style={styles.imagePlaceholder}>Replace with Image</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  const navigateTo = (page) => {
    console.log(`${page} pressed`);
    navigation.navigate(page);
    hideNavbar();
  };

  React.useLayoutEffect(() => {
    navigation.setOptions({
      title: '', // Set title to an empty string to remove it
      headerStyle: {
        backgroundColor: '#008000', // You can adjust the header style as needed
      },
      headerTintColor: 'white', // This sets the color of the back button and other header elements
      headerRight: () => null, // Removes any additional buttons on the right side of the header
    });
  }, [navigation]);
  

  return (
    <ScrollView style={styles.scrollView}>
      <View style={styles.container}>
        {/* Title */}
        <Text style={styles.title}>{Recipe.title}</Text>

        {/* Video */}
        <View style={styles.videoContainer}>
          <WebView
            source={{ uri: Recipe.videoURL }}
            allowsFullscreenVideo
          />
        </View>

        {/* Instructions */}
        <Text style={styles.instructionsTitle}>Steps:</Text>
        <View style={styles.instructionsContainer}>
          {Recipe.InstructionsArray.map((step, index) => (
            <Text key={index} style={styles.instruction}>{`\u2022 ${step}`}</Text>
          ))}
        </View>

      {/* Navbar */}
      <Animatable.View
        ref={navRef}
        style={[styles.navbar, isNavbarVisible ? {} : { height: 0 }]}
        animation="slideInDown"
        duration={500}
        delay={200}>
        <TouchableOpacity style={styles.navLink} onPress={() => navigateTo('Home')}>
          <Text style={styles.navText}>Home</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navLink} onPress={() => navigateTo('Meals')}>
          <Text style={styles.navText}>Meals</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navLink} onPress={() => navigateTo('Review')}>
          <Text style={styles.navText}>Review</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navLink} onPress={() => navigateTo('About')}>
          <Text style={styles.navText}>About</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navCloseBtn} onPress={hideNavbar}>
          <Text style={{ fontSize: 24 }}>⨉</Text>
        </TouchableOpacity>
      </Animatable.View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
    padding: 10,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  imageRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  imagePlaceholder: {
    width: 100,
    height: 100,
    backgroundColor: '#e0e0e0',
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
    lineHeight: 100,
  },
  navbar: {
    position: 'absolute',
    top: 0,
    right: 0,
    height: '100%',
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#008000',
    opacity: 0.95,
    zIndex: 1,
  },
  navLink: {
    marginVertical: 10,
  },
  navText: {
    fontSize: 18,
    color: 'white',
  },
  navBtn: {
    position: 'absolute',
    top: 0,
    right: 10,
    padding: 10,
    zIndex: 2,
  },
  navCloseBtn: {
    marginTop: 20,
  },
  scrollView: {
    flex: 1,
    backgroundColor: '#fff',
  },
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  videoContainer: {
    width: '100%',
    aspectRatio: 16 / 9,
    marginBottom: 20,
  },
  instructionsTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#444',
  },
  instructionsContainer: {
    marginBottom: 20,
  },
  instruction: {
    fontSize: 16,
    marginLeft: 10,
    marginBottom: 5,
    color: '#666',
  },
});

export default PaprikaChickenRiceSteps;