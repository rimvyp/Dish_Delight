import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, FlatList, TouchableOpacity, Image } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
const api = require('../Firebase/client.js');
import { clicked } from './FourButtonScreen';

const AllRecipesScreen = ({ navigation }) => {
  const [isMenuVisible, setMenuVisible] = useState(false);
  const [allDishes, setAllDishes] = useState([]);

  useEffect(() => {
    const fetchAllMeals = async () => {
      try {
        const dishes = await api.getAllMeals();
        setAllDishes(dishes);
      } catch (error) {
        console.error('Error fetching all meals:', error);
      }
    };

    fetchAllMeals();
  }, []);

  useEffect(() => {
    navigation.setOptions({
      headerTitle: () => (
        <View style={styles.headerTitle}>
          <Icon name="book" size={24} color="gold" />
          <Text style={styles.titleText}> All Recipes</Text>
        </View>
      ),
      headerStyle: {
        backgroundColor: '#008000',
      },
      headerTintColor: '#fff',
    });
  }, [navigation]);

  const handleMealClick = (mealID,photo) => {
    console.log(mealID);
    clicked(mealID,photo);
    navigation.navigate('PaprikaChickenRice');
  };

  //puts meals on the screen
return (
  <View style={styles.container}>
    <TextInput
      style={styles.searchInput}
      placeholder="Search recipes..."
    />
<FlatList
  data={allDishes}
  keyExtractor={(item) => item.MealId && item.MealId.toString()}
  renderItem={({ item }) => (
    <TouchableOpacity onPress={() => handleMealClick(item.MealId, item.ImageURL)}>
      <View style={styles.dishItem}>
        <Image source={{ uri: item.ImageURL }} style={styles.dishImage} />
        <Text style={styles.dishName}>{item.Title}</Text>
      </View>
    </TouchableOpacity>
  )}
  ItemSeparatorComponent={() => <View style={styles.separator} />}
/>

  </View>
);
};

const styles = StyleSheet.create({
  headerTitle: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  titleText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    marginLeft: 10,
  },
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    padding: 16,
  },
  searchInput: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 8,
    padding: 8,
    marginBottom: 16,
    backgroundColor: 'white',
  },
  dishItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 10,
    marginVertical: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  dishImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginRight: 10,
  },
  dishName: {
    fontSize: 18,
    color: 'black',
  },
  separator: {
    height: 1,
    backgroundColor: 'lightgray',
  },
});

export default AllRecipesScreen;
