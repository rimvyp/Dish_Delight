import React, { useRef, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import * as Animatable from 'react-native-animatable';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/FontAwesome';


const MealsScreen = () => {
  const navRef = useRef();
  const [isNavbarVisible, setIsNavbarVisible] = useState(false);
  const navigation = useNavigation();

  const toggleNavbar = () => {
    if (isNavbarVisible) {
      hideNavbar();
    } else {
      showNavbar();
    }
  };

  const showNavbar = () => {
    setIsNavbarVisible(true);
    navRef.current.slideInDown();
  };

  const hideNavbar = () => {
    navRef.current.slideOutUp().then(() => {
      setIsNavbarVisible(false);
    });
  };

  const navigateTo = (page) => {
    console.log(`${page} pressed`);
    navigation.navigate(page);
    hideNavbar();
  };

  React.useLayoutEffect(() => {
    navigation.setOptions({
      title: 'Meals',
      headerStyle: {
        backgroundColor: '#008000',
      },
      headerTintColor: 'white',
      headerRight: () => (
        <TouchableOpacity style={styles.navBtn} onPress={toggleNavbar}>
          <Text style={{ fontSize: 24, color: '#008000' }}>☰</Text>
        </TouchableOpacity>
      ),
    });
  }, [navigation, toggleNavbar]);

  const navigateToPaprikaChickenRice = () => {
    navigation.navigate('PaprikaChickenRice');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>List of Meals</Text>
      <TouchableOpacity style={styles.mealContainer} onPress={() => navigateTo('InstantPot')}>
  <View style={styles.imageContainer}>
    <Image
      source={{ uri: 'https://i.postimg.cc/XGxKpPX2/your-image-file-name.jpg' }}
      style={styles.image}
    />
    <TouchableOpacity style={styles.favoriteIcon} onPress={() => {/* Add to favorites logic here */}}>
      <Icon name="star" size={30} color="#FFD700" />
    </TouchableOpacity>
  </View>
  <Text style={styles.mealLink}>Instant-Pot Sausage & Peppers</Text>
</TouchableOpacity>


      {/* Instant-Pot Sausage & Peppers */}
      <TouchableOpacity style={styles.mealContainer} onPress={() => navigateTo('InstantPot')}>
        <View style={styles.imageContainer}>
          <Image
            source={{ uri: 'https://i.postimg.cc/XGxKpPX2/your-image-file-name.jpg' }}
            style={styles.image}
          />
        </View>
        <Text style={styles.mealLink}>Instant-Pot Sausage & Peppers</Text>
      </TouchableOpacity>

      {/* Chicken Paprika & Rice Bake */}
      <TouchableOpacity style={styles.mealContainer} onPress={navigateToPaprikaChickenRice}>
        <View style={styles.imageContainer}>
          <Image
            source={{ uri: 'https://i.postimg.cc/Hk7Gc3jF/paprika-chicken-and-rice-bake.webp' }}
            style={styles.image}
          />
        </View>
        <Text style={styles.mealLink}>Chicken Paprika & Rice Bakeeeee</Text>
      </TouchableOpacity>

      {/* Navbar */}
      <Animatable.View
        ref={navRef}
        style={[styles.navbar, isNavbarVisible ? {} : { height: 0 }]}
        animation="slideInDown"
        duration={500}
        delay={200}
      >
        <TouchableOpacity style={styles.navLink} onPress={() => navigateTo('Home')}>
          <Text style={styles.navText}>Home</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navLink} onPress={() => navigateTo('Meals')}>
          <Text style={styles.navText}>Meals</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navLink} onPress={() => navigateTo('Review')}>
          <Text style={styles.navText}>Review</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navLink} onPress={() => navigateTo('About')}>
          <Text style={styles.navText}>About</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navCloseBtn} onPress={hideNavbar}>
          <Text style={{ fontSize: 24 }}>⨉</Text>
        </TouchableOpacity>
      </Animatable.View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    paddingTop: 20,
    paddingLeft: 20,
  },
  heading: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  mealContainer: {
    marginBottom: 20,
  },
  imageContainer: {
    marginBottom: 5,
  },
  image: {
    width: '100%',
    height: 150,
    resizeMode: 'cover',
    borderRadius: 8,
  },
  mealLink: {
    fontSize: 18,
    textAlign: 'center',
  },
  navbar: {
    position: 'absolute',
    top: 0,
    right: 0,
    height: '100%',
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#008000',
    opacity: 0.95,
    zIndex: 1,
  },
  navLink: {
    marginVertical: 10,
  },
  navText: {
    fontSize: 18,
    color: 'white',
  },
  navBtn: {
    position: 'absolute',
    top: 0,
    right: 10,
    padding: 10,
    zIndex: 2,
  },
  navCloseBtn: {
    marginTop: 20,
  },
  favoriteIcon: {
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 2,
  },
  
});

export default MealsScreen;