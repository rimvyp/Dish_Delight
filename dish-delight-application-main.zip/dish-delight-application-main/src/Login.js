import React, { useState, useEffect } from 'react';
import {
 ScrollView, Alert, Keyboard, KeyboardAvoidingView, Platform, View, Image, Text, TextInput, Button, StyleSheet
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
const api = require('../Firebase/client.js');
let ID = 0;


const WelcomeScreen = () => {
  let [email, setEmail] = useState('');
  let [password, setPassword] = useState('');
  const [isKeyboardVisible, setKeyboardVisible] = useState(false);
  const navigation = useNavigation();
  
  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => setKeyboardVisible(true)
      );
      const keyboardDidHideListener = Keyboard.addListener(
        'keyboardDidHide',
        () => setKeyboardVisible(false)
        );
        
        return () => {
          keyboardDidHideListener.remove();
          keyboardDidShowListener.remove();
        };
      }, []);
      
      const handleLogin = async () => {
        try 
        {
          //attempts to log in users
          const login = await api.loginUser(String(email),String(password));
          
          if (login.message === "Login successful") 
          {
            setEmail('');
            setPassword('');
            Alert.alert("Login Successful", "You have logged in successfully.");
            Alert.alert("Login Successful", "You have logged in successfully.");
            storeID(login.id);
          navigation.navigate('Home');
          }

        else 
        {
          Alert.alert(
          "Login Failed",
          "Username or password is incorrect",
          [{ text: "OK", onPress: () => console.log("OK Pressed") }]
          );
          console.log("Denied");
        }
      } catch (error) {
        console.error(error);
      }
    };



  const handleGoToRegister = () => {
    navigateTo('RegisterScreen')
  };

  
  const navigateTo = (page) => {
    console.log(`${page} pressed`);
    navigation.reset({
      index: 0,
      routes: [{ name: page }],
    });
  };
  

  return (
    <KeyboardAvoidingView
      style={styles.keyboardAvoidingView}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS === "ios" ? 64 : 0}
    >
      <ScrollView style={styles.scrollView}>
        <View style={styles.container}>
          <Image
            source={{ uri: 'https://i.postimg.cc/4yrNXrys/Recipe-Haven.png' }}
            style={styles.image}
          />
          <Text style={styles.text}>Healthy, Quick and Cheap Recipes For You!</Text>
          <View style={styles.form}>
            <TextInput
              style={styles.input}
              placeholder="Email"
              onChangeText={setEmail}
              value={email}
            />
            <TextInput
              style={styles.input}
              placeholder="Password"
              secureTextEntry
              onChangeText={setPassword}
              value={password}
            />
            <Button
              title="Login"
              onPress={handleLogin}
              color="rgb(68, 214, 44)"
            />
            <Button
              title="Register"
              onPress={handleGoToRegister}
              color="rgb(68, 214, 44)"
            />
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
  
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white', // Set background color to white
  },
  text: {
    textAlign: 'center',
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  form: {
    width: '80%',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
  },
  button: {
    marginBottom: 20,
  },
  image: {
    width: '60%',
    height: 250,
    marginBottom: 30, // Increase bottom margin to move image down
  },
  keyboardAvoidingView: {
    flex: 1,
    backgroundColor: 'white', // Ensure the entire background is white
  },
  scrollView: {
    flex: 1,
    backgroundColor: 'white', // Ensure the entire background is white
  },
});

function storeID(x)
{
  ID = x.charAt(x.length-1)
}


export const getId = () => {
  return ID
  // Alert.alert(ID);
  // console.log("User ID is "+ID);
};

export default WelcomeScreen;
