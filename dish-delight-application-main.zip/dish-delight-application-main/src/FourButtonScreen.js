import React, { useRef, useState, useEffect } from 'react';
import { Alert, View, Text, TouchableOpacity, StyleSheet, Dimensions, Image } from 'react-native';
import * as Animatable from 'react-native-animatable';
import { useNavigation } from '@react-navigation/native';
import FavoritesScreen from './FavoritesScreen';
import { getId } from './Login';
const api = require('../Firebase/client.js');
let mealClicked = 0; //Meal ID of meal clicked
let mealImageClicked = "";

const FourButtonScreen = ({ navigation }) => {
  const screenWidth = Dimensions.get('window').width;
  const navRef = useRef();
  const [isNavbarVisible, setIsNavbarVisible] = useState(false);

 //backend
 const ID = getId(); //gets ID from Login
 let homeScreenData; // where the JSON will be stored

 //Suggested 1
 const [suggestedST1, setSuggestedST1] = useState("Loading...");
 const [suggestedI1, setSuggestedI1] = useState('https://i.postimg.cc/mZMm8ncV/Screenshot-from-2023-12-11-18-30-50.png');
 const [suggestedID1, setSuggestedMealID1] = useState(0);

 //Suggested 2
 const [suggestedST2, setSuggestedST2] = useState("Loading...");
 const [suggestedI2, setSuggestedI2] = useState('https://i.postimg.cc/mZMm8ncV/Screenshot-from-2023-12-11-18-30-50.png');
 const [suggestedID2, setSuggestedMealID2] = useState(0);

 //Suggested 3
 const [suggestedST3, setSuggestedST3] = useState("Loading...");
 const [suggestedI3, setSuggestedI3] = useState('https://i.postimg.cc/mZMm8ncV/Screenshot-from-2023-12-11-18-30-50.png');
 const [suggestedID3, setSuggestedMealID3] = useState(0);

 //Latest 1
 const [latestST1, setLatestST1] = useState("Loading...");
 const [latestI1, setLatestI1] = useState('https://i.postimg.cc/mZMm8ncV/Screenshot-from-2023-12-11-18-30-50.png');
 const [latestID1, setLatestMealID1] = useState(0);

 //Latest 2
 const [latestST2, setLatestST2] = useState("Loading...");
 const [latestI2, setLatestI2] = useState('https://i.postimg.cc/mZMm8ncV/Screenshot-from-2023-12-11-18-30-50.png');
 const [latestID2, setLatestMealID2] = useState(0);

 //Latest 3
 const [latestST3, setLatestST3] = useState("Loading...");
 const [latestI3, setLatestI3] = useState('https://i.postimg.cc/mZMm8ncV/Screenshot-from-2023-12-11-18-30-50.png');
 const [latestID3, setLatestMealID3] = useState(0);

 //Favourite 1
 const [favST1, setFavST1] = useState("Loading...");
 const [favI1, setFavI1] = useState('https://i.postimg.cc/mZMm8ncV/Screenshot-from-2023-12-11-18-30-50.png');
 const [favMealID1, setFavMealID1] = useState(0);

 //Favourite 2
 const [favST2, setFavST2] = useState("Loading...");
 const [favI2, setFavI2] = useState('https://i.postimg.cc/mZMm8ncV/Screenshot-from-2023-12-11-18-30-50.png');
 const [favMealID2, setFavMealID2] = useState(0);

 //Favourite 3
 const [favST3, setFavST3] = useState("Loading...");
 const [favI3, setFavI3] = useState('https://i.postimg.cc/mZMm8ncV/Screenshot-from-2023-12-11-18-30-50.png');
 const [favMealID3, setFavMealID3] = useState(0);

 let homeScreen = async () =>{
 try
 {
  homeScreenData = await api.getHomeScreen(ID);

   //Suggested 1
   setSuggestedST1(homeScreenData.suggested[0].Title);
   setSuggestedI1(homeScreenData.suggested[0].ImageURL);
   setSuggestedMealID1(homeScreenData.suggested[0].MealId)

   //Suggested 2
   setSuggestedST2(homeScreenData.suggested[1].Title);
   setSuggestedI2(homeScreenData.suggested[1].ImageURL);
   setSuggestedMealID2(homeScreenData.suggested[1].MealId)

   //Suggested 3
   setSuggestedST3(homeScreenData.suggested[2].Title);
   setSuggestedI3(homeScreenData.suggested[2].ImageURL);
   setSuggestedMealID3(homeScreenData.suggested[2].MealId)

   //Latest 1
   setLatestST1(homeScreenData.latestMeals[0].Title);
   setLatestI1(homeScreenData.latestMeals[0].ImageURL);
   setLatestMealID1(homeScreenData.latestMeals[0].MealId)

   //Latest 2
   setLatestST2(homeScreenData.latestMeals[1].Title);
   setLatestI2(homeScreenData.latestMeals[1].ImageURL);
   setLatestMealID2(homeScreenData.latestMeals[1].MealId)

   //Latest 3
   setLatestST3(homeScreenData.latestMeals[2].Title);
   setLatestI3(homeScreenData.latestMeals[2].ImageURL);
   setLatestMealID3(homeScreenData.latestMeals[2].MealId)

   //Favourite 1
   setFavST1(homeScreenData.favourites[0].Title);
   setFavI1(homeScreenData.favourites[0].ImageURL);
   setFavMealID1(homeScreenData.favourites[0].MealId)

   //Favourite 2
   setFavST2(homeScreenData.favourites[1].Title);
   setFavI2(homeScreenData.favourites[1].ImageURL);
   setFavMealID2(homeScreenData.favourites[1].MealId)

   //Favourite 3
   setFavST3(homeScreenData.favourites[2].Title);
   setFavI3(homeScreenData.favourites[2].ImageURL);
   setFavMealID3(homeScreenData.favourites[2].MealId)
 }

 catch(error)
 {
   console.log(error);
 }
}

function clicked(navTo,x,I1)
{
  mealClicked = x;
  mealImageClicked = I1;
  console.log("Meal Clicked = "+mealClicked);
  console.log("Meal Image = "+mealClicked);
  navigation.navigate(navTo);
}

useEffect(() => {
 homeScreen();
}, []);

  const toggleNavbar = () => {
    if (isNavbarVisible) {
      hideNavbar();
    } else {
      showNavbar();
    }
  };


  const confirmLogout = () => {
    console.log('Logout button pressed');
    Alert.alert(
      "Logout", 
      "Are you sure you want to log out?",
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel"
        },
        { text: "OK", onPress: () => navigateTo('WelcomeScreen') }
      ],
      { cancelable: false }
    );
  };

  const showNavbar = () => {
    setIsNavbarVisible(true);
    navRef.current.slideInDown();
  };

  const hideNavbar = () => {
    navRef.current.slideOutUp().then(() => {
      setIsNavbarVisible(false);
    });
  };

  const Section = ({ title, navTo, ST1, I1, ID1, ST2, I2, ID2, ST3, I3, ID3}) => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.imageRow}>
        <TouchableOpacity style={styles.imageButton} onPress={() => clicked(navTo,ID1,I1)}>
          <Image
          source={{ uri: I1 }}
          style={styles.image}
        />
        <Text style={styles.sectionSubTitle}>{ST1}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.imageButton} onPress={() => clicked(navTo,ID2,I2)}>
        <Image
          source={{ uri: I2 }}
          style={styles.image}
        />
          <Text style={styles.sectionSubTitle}>{ST2}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.imageButton} onPress={() => clicked(navTo,ID3,I3)}>
        <Image
          source={{ uri: I3 }}
          style={styles.image}
        />
          <Text style={styles.sectionSubTitle}>{ST3}</Text>
        </TouchableOpacity>
      </View>
    </View>
);


  const navigateTo = (page) => {
    console.log(`${page} pressed`);
    navigation.navigate(page);
    hideNavbar();
  };

  React.useLayoutEffect(() => {
    navigation.setOptions({
      title: 'Home',
      headerStyle: {
        backgroundColor: '#008000', // Set the desired background color (green) here
      },
      headerTintColor: 'white',
      headerRight: () => (
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={{ fontSize: 24, color: 'white', marginRight: 10 }}>→</Text>
          <TouchableOpacity
            style={styles.invisibleButton}
            onPress={confirmLogout}
          />
        </View>
      ),
      // ... (other header options)
    });
  }, [navigation, confirmLogout]);

  return (
    <View style={styles.container}>
      {/* Sections */}
      <Section title="Favorites" 
      navTo = 'PaprikaChickenRice' 
      ST1 = {favST1} 
      I1 = {favI1}
      ID1 = {favMealID1}
      ST2 = {favST2}
      I2 = {favI2}
      ID2 = {favMealID2}
      ST3 = {favST3}
      I3 = {favI3}
      ID3 = {favMealID3}/>

      <Section title="Latest Meals"
      navTo = 'PaprikaChickenRice'
      ST1 = {latestST1}
      I1 = {latestI1}
      ID1 = {latestID1}
      ST2 = {latestST2}
      I2 = {latestI2}
      ID2 = {latestID2}
      ST3 = {latestST3}
      I3 = {latestI3}
      ID3 = {latestID3}/>

      <Section title="Suggested"
      navTo = 'PaprikaChickenRice' 
      ST1 = {suggestedST1} 
      I1 = {suggestedI1}
      ID1 = {suggestedID1}
      ST2 = {suggestedST2}
      I2 = {suggestedI2}
      ID2 = {suggestedID2}
      ST3 = {suggestedST3}
      I3 = {suggestedI3}
      ID3 = {suggestedID3}/>

    

      {/* Hotbar */}
      <View style={styles.hotbar}>
  <TouchableOpacity style={styles.button} onPress={() =>navigateTo('AllRecipes')}>
    <Text style={styles.buttonText}>See All Meals</Text>
  </TouchableOpacity>
  <TouchableOpacity style={styles.button} onPress={() => navigateTo('Favorites')}>
    <Text style={styles.buttonText}>Favourites</Text>
  </TouchableOpacity>
</View>

      {/* Navbar */}
      <Animatable.View
        ref={navRef}
        style={[styles.navbar, isNavbarVisible ? {} : { height: 0, overflow: 'hidden' }]}
        animation="slideInDown"
        duration={500}
        delay={200}>
        <TouchableOpacity style={styles.navLink} onPress={() => navigateTo('Home')}>
          <Text style={styles.navText}>Home</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navLink} onPress={() => navigateTo('Meals')}>
          <Text style={styles.navText}>Meals</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navLink} onPress={() => navigateTo('Review')}>
          <Text style={styles.navText}>Review</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navLink} onPress={() => navigateTo('About')}>
          <Text style={styles.navText}>About</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navCloseBtn} onPress={hideNavbar}>
          <Text style={{ fontSize: 24 }}>⨉</Text>
        </TouchableOpacity>
      </Animatable.View>
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
    padding: 10,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  sectionSubTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    marginTop: 10,
    textAlign: 'center',
  },
  imageRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  imagePlaceholder: {
    width: 100,
    height: 100,
    backgroundColor: '#e0e0e0',
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
    lineHeight: 100,
  },
  image: {
    width: 100, // Adjust the width as needed
    height: 100, // Adjust the height as needed
  },
  hotbar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#ddd',
    padding: 10,
  },
  button: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    marginHorizontal: 5,
    backgroundColor: '#008000',
    borderRadius: 5,
  },
  buttonText: {
    fontSize: 16,
    color: 'white',
  },
  navbar: {
    position: 'absolute',
    top: 0,
    right: 0,
    height: '100%',
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#008000',
    opacity: 0.95,
    zIndex: 1,
  },
  navLink: {
    marginVertical: 10,
  },
  navText: {
    fontSize: 18,
    color: 'white',
  },
   navBtn: {
    position: 'absolute',
    top: 0,
    right: 10,
    padding: 10,
    zIndex: 2,
  },
  navCloseBtn: {
    marginTop: 20,
  },
  navCloseBtn: {
    marginTop: 20,
  },
  invisibleButton: {
    position: 'absolute',
    top: 0,
    right: 0,
    width: 50, // Adjust the size to cover the arrow
    height: 50,
    zIndex: 3,
    backgroundColor: 'transparent', // Keep the button invisible
  },
});

export const getMealID = () => {
  // Alert.alert(ID);
  console.log("Meal ID is "+mealClicked);
  return mealClicked;
};

export const getImage = () => {
  // Alert.alert(ID);
  console.log("Meal Image is "+mealImageClicked);
  return mealImageClicked;
};

export const clicked = (x, I1) => {
  mealClicked = x;
  mealImageClicked = I1;
};

export default FourButtonScreen;




